Downloaded by "Download All Images" extension

Page: https://preview.themeforest.net/item/funden-crowdfunding-charity-html5-template/full_screen_preview/33265938?clickid=VO50IOyl0xyNWtfxnTS7fUdWUkAwAbRAJVWDV40&iradid=275988&iradtype=ONLINE_TRACKING_LINK&irgwc=1&irmptype=mediapartner&irpid=1223214&mp_value1=&utm_campaign=af_impact_radius_1223214&utm_medium=affiliate&utm_source=impact_radius
Date: 1/13/2023, 3:37:12 PM

Name, Link
----------
envato_market-a5ace93f8482e885ae008eb481b9451d379599dfed2486.svg, https://public-assets.envato-static.com/assets/logos/envato_market-a5ace93f8482e885ae008eb481b9451d379599dfed24868e52b6b2d66f5cf633.svg
logos-6f8a015ab6d9602102f6c4dde38bf1a128f2647f20b76023c4793c.png, https://public-assets.envato-static.com/assets/generated_sprites/logos-6f8a015ab6d9602102f6c4dde38bf1a128f2647f20b76023c4793c2d3d86e57c.png
common-14f8bc60470b39265fe5c01e92035209bd04b91cd7da99d59ca3c.png, https://public-assets.envato-static.com/assets/generated_sprites/common-14f8bc60470b39265fe5c01e92035209bd04b91cd7da99d59ca3ccd9de5eac62.png
logo.png, https://demo.webtend.net/html/funden/assets/img/logo.png
logo-white.png, https://demo.webtend.net/html/funden/assets/img/logo-white.png
apple-touch-icon-72x72-precomposed.png, https://public-assets.envato-static.com/icons/themeforest.net/apple-touch-icon-72x72-precomposed.png
hero-line.png, https://demo.webtend.net/html/funden/assets/img/hero/hero-line.png
apple-touch-icon-114x114-precomposed.png, https://public-assets.envato-static.com/icons/themeforest.net/apple-touch-icon-114x114-precomposed.png
hero-line-2.png, https://demo.webtend.net/html/funden/assets/img/hero/hero-line-2.png
apple-touch-icon-144x144-precomposed.png, https://public-assets.envato-static.com/icons/themeforest.net/apple-touch-icon-144x144-precomposed.png
hero-one-small.jpg, https://demo.webtend.net/html/funden/assets/img/hero/hero-one-small.jpg
apple-touch-icon-precomposed.png, https://public-assets.envato-static.com/icons/themeforest.net/apple-touch-icon-precomposed.png
hero-one-big.jpg, https://demo.webtend.net/html/funden/assets/img/hero/hero-one-big.jpg
hero-one-small-2.jpg, https://demo.webtend.net/html/funden/assets/img/hero/hero-one-small-2.jpg
about-one.jpg, https://demo.webtend.net/html/funden/assets/img/about/about-one.jpg
01.jpg, https://demo.webtend.net/html/funden/assets/img/author-thumbs/01.jpg
03.jpg, https://demo.webtend.net/html/funden/assets/img/author-thumbs/03.jpg
02.jpg, https://demo.webtend.net/html/funden/assets/img/author-thumbs/02.jpg
04.jpg, https://demo.webtend.net/html/funden/assets/img/author-thumbs/04.jpg
05.jpg, https://demo.webtend.net/html/funden/assets/img/author-thumbs/05.jpg
06.jpg, https://demo.webtend.net/html/funden/assets/img/author-thumbs/06.jpg
01.png, https://demo.webtend.net/html/funden/assets/img/partners/01.png
02.png, https://demo.webtend.net/html/funden/assets/img/partners/02.png
03.png, https://demo.webtend.net/html/funden/assets/img/partners/03.png
04.png, https://demo.webtend.net/html/funden/assets/img/partners/04.png
05.png, https://demo.webtend.net/html/funden/assets/img/partners/05.png
06.png, https://demo.webtend.net/html/funden/assets/img/partners/06.png
07.png, https://demo.webtend.net/html/funden/assets/img/partners/07.png
08.png, https://demo.webtend.net/html/funden/assets/img/partners/08.png
01.jpg, https://demo.webtend.net/html/funden/assets/img/latest-news/01.jpg
02.jpg, https://demo.webtend.net/html/funden/assets/img/latest-news/02.jpg
03.jpg, https://demo.webtend.net/html/funden/assets/img/latest-news/03.jpg
hero-one-bg.jpg, https://demo.webtend.net/html/funden/assets/img/hero/hero-one-bg.jpg
author-note-pattern.png, https://demo.webtend.net/html/funden/assets/img/about/author-note-pattern.png
project-grid-06.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-grid-06.jpg
project-grid-07.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-grid-07.jpg
project-grid-08.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-grid-08.jpg
project-grid-09.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-grid-09.jpg
project-grid-01.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-grid-01.jpg
project-grid-02.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-grid-02.jpg
project-grid-03.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-grid-03.jpg
project-grid-04.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-grid-04.jpg
project-grid-05.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-grid-05.jpg
01.jpg, https://demo.webtend.net/html/funden/assets/img/cta/01.jpg
world-map.png, https://demo.webtend.net/html/funden/assets/img/world-map.png
project-slider-01.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-slider-01.jpg
project-slider-02.jpg, https://demo.webtend.net/html/funden/assets/img/project/project-slider-02.jpg
